import java.util.Scanner;

public class Report {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Cities and types of accidents
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        String[] vehicleTypes = {"Car", "Motorbike"};

        // Two-dimensional array to store accidents: rows for cities, columns for vehicle types
        int[][] accidents = new int[cities.length][vehicleTypes.length];

        // Initialize accident data
        accidents[0][0] = 155; // Cape Town Car accidents
        accidents[0][1] = 121; // Cape Town Motorbike accidents
        accidents[1][0] = 178; // Johannesburg Car accidents
        accidents[1][1] = 145; // Johannesburg Motorbike accidents
        accidents[2][0] = 112; // Port Elizabeth Car accidents
        accidents[2][1] = 89;  // Port Elizabeth Motorbike accidents

        // Collect user input for additional accidents
        for (int i = 0; i < cities.length; i++) {
            System.out.println("Recording accidents for " + cities[i]);
            System.out.print("Enter additional number of car accidents: ");
            int additionalCarAccidents = scanner.nextInt();
            System.out.print("Enter additional number of motorbike accidents: ");
            int additionalBikeAccidents = scanner.nextInt();

            // Update the accidents array
            accidents[i][0] += additionalCarAccidents;
            accidents[i][1] += additionalBikeAccidents;
        }

        // Generate and display the accident report
        displayReport(cities, vehicleTypes, accidents);

        // Find and display the city with the highest number of total accidents
        findCityWithHighestAccidents(cities, accidents);

        scanner.close();
    }

    private static void displayReport(String[] cities, String[] vehicleTypes, int[][] accidents) {
        System.out.println("\nAccident Report:");
        System.out.printf("%-15s %-15s %-15s %-15s%n", "City", "Car Accidents", "Motorbike Accidents", "Total Accidents");
        System.out.println("---------------------------------------------------------------");

        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1];
            System.out.printf("%-15s %-15d %-15d %-15d%n", cities[i], accidents[i][0], accidents[i][1], totalAccidents);
        }
    }

    private static void findCityWithHighestAccidents(String[] cities, int[][] accidents) {
        int highestAccidents = 0;
        String cityWithHighestAccidents = "";

        for (int i = 0; i < cities.length; i++) {
            int totalAccidents = accidents[i][0] + accidents[i][1];
            if (totalAccidents > highestAccidents) {
                highestAccidents = totalAccidents;
                cityWithHighestAccidents = cities[i];
            }
        }

        System.out.printf("\nCity with the highest number of road accidents: %s (%d accidents)\n", cityWithHighestAccidents, highestAccidents);
    }
}
