import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class AccidentData {
    private int carAccidents;
    private int bikeAccidents;

    public AccidentData(int carAccidents, int bikeAccidents) {
        this.carAccidents = carAccidents;
        this.bikeAccidents = bikeAccidents;
    }

    public void recordCarAccident(int count) {
        carAccidents += count;
    }

    public void recordBikeAccident(int count) {
        bikeAccidents += count;
    }

    public int getCarAccidents() {
        return carAccidents;
    }

    public int getBikeAccidents() {
        return bikeAccidents;
    }
}

public class Test {
    private static final String[] CITIES = {"Cape Town", "Johannesburg", "Port Elizabeth"};
    private Map<String, AccidentData> accidentMap;

    public Test() {
        accidentMap = new HashMap<>();
        // Initialize accident data for the cities
        accidentMap.put("Cape Town", new AccidentData(155, 121));
        accidentMap.put("Johannesburg", new AccidentData(178, 145));
        accidentMap.put("Port Elizabeth", new AccidentData(112, 89)); // Initialize with given data
    }

    public void recordAccidents(String city, int cars, int bikes) {
        AccidentData data = accidentMap.get(city);
        if (data != null) {
            data.recordCarAccident(cars);
            data.recordBikeAccident(bikes);
        } else {
            System.out.println("Invalid city name.");
        }
    }

    public void displayReport() {
        System.out.println("\nAccident Report:");
        System.out.printf("%-15s %-15s %-15s%n", "City", "Car Accidents", "Bike Accidents");
        System.out.println("-------------------------------------------------");
        for (String city : CITIES) {
            AccidentData data = accidentMap.get(city);
            System.out.printf("%-15s %-15d %-15d%n", city, data.getCarAccidents(), data.getBikeAccidents());
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Test tracker = new Test();

        // Prompt user for accident data in Port Elizabeth
        System.out.println("Recording accidents for Port Elizabeth");
        System.out.print("Enter number of car accidents: ");
        int carAccidents = scanner.nextInt();
        System.out.print("Enter number of bike accidents: ");
        int bikeAccidents = scanner.nextInt();

        // Record the accidents for Port Elizabeth
        tracker.recordAccidents("Port Elizabeth", carAccidents, bikeAccidents);

        // Display the report
        tracker.displayReport();
        scanner.close();

    }
}
