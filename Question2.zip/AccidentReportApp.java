import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AccidentReportApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<RoadAccidents> accidentsList = new ArrayList<>();

        // Input data for vehicle accidents
        System.out.println("Enter the number of accidents to record:");
        int numberOfAccidentsToRecord = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < numberOfAccidentsToRecord; i++) {
            System.out.println("\nEnter details for accident " + (i + 1) + ":");
            System.out.print("Vehicle Type (Car/Motorbike): ");
            String vehicleType = scanner.nextLine();
            System.out.print("City: ");
            String city = scanner.nextLine();
            System.out.print("Number of Accidents: ");
            int numberOfAccidents = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Create a new VehicleAccident and add it to the list
            VehicleAccident accident = new VehicleAccident(vehicleType, city, numberOfAccidents);
            accidentsList.add(accident);
        }

        // Display the accident report
        displayAccidentReport(accidentsList);
        scanner.close();
    }

    private static void displayAccidentReport(List<RoadAccidents> accidentsList) {
        System.out.println("\nAccident Report:");
        System.out.printf("%-15s %-15s %-15s%n", "Vehicle Type", "City", "Number of Accidents");
        System.out.println("----------------------------------------------------");

        for (RoadAccidents accident : accidentsList) {
            System.out.printf("%-15s %-15s %-15d%n",
                    accident.getAccidentVehicleType(),
                    accident.getCity(),
                    accident.getAccidentTotal());
        }
    }
}
