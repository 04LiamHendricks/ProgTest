abstract class RoadAccidents implements IRoadAccidents {
    private String vehicleType;
    private String city;
    private int numberOfAccidents;

    // Constructor
    public RoadAccidents(String vehicleType, String city, int numberOfAccidents) {
        this.vehicleType = vehicleType;
        this.city = city;
        this.numberOfAccidents = numberOfAccidents;
    }

    // Get methods
    @Override
    public String getAccidentVehicleType() {
        return vehicleType;
    }

    @Override
    public String getCity() {
        return city;
    }

    @Override
    public int getAccidentTotal() {
        return numberOfAccidents;
    }
}
