class VehicleAccident extends RoadAccidents {
    public VehicleAccident(String vehicleType, String city, int numberOfAccidents) {
        super(vehicleType, city, numberOfAccidents);
    }
}
